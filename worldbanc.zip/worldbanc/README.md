# WorldBanc

A repository for the WorldBanc project, a filesystem for the Learn Terminals and Shells course on [Boot.dev](https://www.boot.dev).
